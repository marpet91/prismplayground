﻿using System.Windows.Controls;
using System.Windows.Media;
using Prism.Mvvm;

namespace Snake.App.Views.Main
{
    public class MainWindowViewModel : BindableBase
    {
        private Canvas _snakefield;
        public Canvas SnakeField
        {
            get => _snakefield;
            set => SetProperty(ref _snakefield, value);
        }
        
        private string _gamepoints;
        public string GamePoints
        {
            get => _gamepoints; 
            set => SetProperty(ref _gamepoints, value);
        }

        public MainWindowViewModel()
        {
            GamePoints = "Points: 0";

            TextBlock text = new TextBlock();
            text.Text = "Adolf Hitler";
            text.Background = Brushes.Black;

            _snakefield = new Canvas();
            SnakeField.Children.Add(text);
        }
    }
}