﻿using System;
using System.Collections.ObjectModel;

namespace SteaContacts.Core
{
    public interface IDataProvider
    {
        ObservableCollection<Persons> GetCollectionPersons();
    }
}