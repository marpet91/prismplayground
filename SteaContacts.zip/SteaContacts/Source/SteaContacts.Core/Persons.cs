﻿namespace SteaContacts.Core
{
    public class Persons
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Department { get; set; }
    }
}