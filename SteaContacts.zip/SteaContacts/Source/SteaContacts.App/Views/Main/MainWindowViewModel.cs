﻿using System.Collections.ObjectModel;
using System.Windows.Controls;
using Prism.Commands;
using Prism.Mvvm;
using SteaContacts.Core;
using SteaContacts.Infrastructur.Local;

namespace SteaContacts.App.Views.Main
{
    public class MainWindowViewModel : BindableBase
    {
        public MainWindowViewModel()
        {
            
        }
    }
}