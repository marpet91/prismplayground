﻿using Prism.Mvvm;

namespace SteaContacts.App.Views.AddContact
{
    public class AddContactViewModel : BindableBase
    {
        
    }
}