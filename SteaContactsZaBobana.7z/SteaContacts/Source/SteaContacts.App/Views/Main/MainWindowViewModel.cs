﻿using Prism.Commands;
using Prism.Mvvm;
using System.Windows;
using System.Windows.Input;

namespace SteaContacts.App.Views.Main
{
    public class MainWindowViewModel : BindableBase
    {
        private string _company;

        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }

        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }


        public MainWindowViewModel()
        {
        }

        private DelegateCommand addPersonCommand;
        public ICommand AddPersonCommand => addPersonCommand ??= new DelegateCommand(AddPerson);

        private void AddPerson()
        {
            MessageBox.Show($"{FirstName} is working at {Company}");
        }
    }
}