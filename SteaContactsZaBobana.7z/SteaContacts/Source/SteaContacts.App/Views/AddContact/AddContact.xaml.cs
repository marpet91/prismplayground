﻿using System.Windows;

namespace SteaContacts.App.Views.AddContact
{
    public partial class AddContact : Window
    {
        public AddContact()
        {
            InitializeComponent();
        }
    }
}