﻿using System.Collections.ObjectModel;
using SteaContacts.Core;

namespace SteaContacts.Infrastructur.Local
{
    public class DataProviderLocal : IDataProvider
    {
        public ObservableCollection<Persons> GetCollectionPersons()
        {
            ObservableCollection<Persons> personsList = new ObservableCollection<Persons>();
            
            personsList.Add(new Persons()
            {
                FirstName = "Boban",
                LastName = "Milojevic",
                Department = "STEA Konzern"
            });
            
            personsList.Add(new Persons()
            {
                FirstName = "Marko",
                LastName = "Petrovic",
                Department = "Illwerke Schnarchfirma :)"
            });

            return personsList;
        }
    }
}